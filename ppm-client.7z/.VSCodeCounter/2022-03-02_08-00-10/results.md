# Summary

Date : 2022-03-02 08:00:10

Directory c:\Users\Chitambo\Documents\pureJavascript\nuxtjs-crud-with-auth-using-php-api-master

Total : 30 files,  26758 codes, 17 comments, 132 blanks, all 26907 lines

summary / [details](details.md) / [diff summary](diff.md) / [diff details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 2 | 24,781 | 0 | 2 | 24,783 |
| Vue | 19 | 1,615 | 0 | 50 | 1,665 |
| JavaScript | 4 | 274 | 13 | 38 | 325 |
| Markdown | 2 | 44 | 0 | 37 | 81 |
| PHP | 1 | 43 | 0 | 3 | 46 |
| XML | 1 | 1 | 0 | 1 | 2 |
| SCSS | 1 | 0 | 4 | 1 | 5 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 30 | 26,758 | 17 | 132 | 26,907 |
| assets | 1 | 0 | 4 | 1 | 5 |
| layouts | 2 | 118 | 0 | 6 | 124 |
| middleware | 2 | 10 | 0 | 0 | 10 |
| pages | 18 | 1,540 | 0 | 47 | 1,587 |
| pages\banks | 3 | 171 | 0 | 8 | 179 |
| pages\details | 4 | 593 | 0 | 6 | 599 |
| pages\district | 3 | 210 | 0 | 7 | 217 |
| pages\product | 4 | 298 | 0 | 5 | 303 |
| static | 1 | 1 | 0 | 1 | 2 |
| store | 2 | 217 | 0 | 31 | 248 |

summary / [details](details.md) / [diff summary](diff.md) / [diff details](diff-details.md)