# Details

Date : 2022-03-02 08:00:10

Directory c:\Users\Chitambo\Documents\pureJavascript\nuxtjs-crud-with-auth-using-php-api-master

Total : 30 files,  26758 codes, 17 comments, 132 blanks, all 26907 lines

[summary](results.md) / details / [diff summary](diff.md) / [diff details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 38 | 0 | 32 | 70 |
| [assets/variables.scss](/assets/variables.scss) | SCSS | 0 | 4 | 1 | 5 |
| [layouts/default.vue](/layouts/default.vue) | Vue | 75 | 0 | 3 | 78 |
| [layouts/error.vue](/layouts/error.vue) | Vue | 43 | 0 | 3 | 46 |
| [middleware/auth.js](/middleware/auth.js) | JavaScript | 5 | 0 | 0 | 5 |
| [middleware/guest.js](/middleware/guest.js) | JavaScript | 5 | 0 | 0 | 5 |
| [nuxt.config.js](/nuxt.config.js) | JavaScript | 53 | 13 | 12 | 78 |
| [package-lock.json](/package-lock.json) | JSON | 24,756 | 0 | 1 | 24,757 |
| [package.json](/package.json) | JSON | 25 | 0 | 1 | 26 |
| [pages/Login.vue](/pages/Login.vue) | Vue | 62 | 0 | 2 | 64 |
| [pages/Signup.vue](/pages/Signup.vue) | Vue | 69 | 0 | 0 | 69 |
| [pages/banks/_banksid.vue](/pages/banks/_banksid.vue) | Vue | 0 | 0 | 1 | 1 |
| [pages/banks/create-banks.vue](/pages/banks/create-banks.vue) | Vue | 97 | 0 | 3 | 100 |
| [pages/banks/index.vue](/pages/banks/index.vue) | Vue | 74 | 0 | 4 | 78 |
| [pages/details/_detailsid.vue](/pages/details/_detailsid.vue) | Vue | 88 | 0 | 2 | 90 |
| [pages/details/create-details.vue](/pages/details/create-details.vue) | Vue | 259 | 0 | 1 | 260 |
| [pages/details/create-detailsx.vue](/pages/details/create-detailsx.vue) | Vue | 168 | 0 | 2 | 170 |
| [pages/details/index.vue](/pages/details/index.vue) | Vue | 78 | 0 | 1 | 79 |
| [pages/district/_districtid.vue](/pages/district/_districtid.vue) | Vue | 80 | 0 | 2 | 82 |
| [pages/district/create-district.vue](/pages/district/create-district.vue) | Vue | 64 | 0 | 4 | 68 |
| [pages/district/index.vue](/pages/district/index.vue) | Vue | 66 | 0 | 1 | 67 |
| [pages/index.vue](/pages/index.vue) | Vue | 94 | 0 | 16 | 110 |
| [pages/indexx.php](/pages/indexx.php) | PHP | 43 | 0 | 3 | 46 |
| [pages/product/Create-Product.vue](/pages/product/Create-Product.vue) | Vue | 71 | 0 | 2 | 73 |
| [pages/product/Create-Producty.vue](/pages/product/Create-Producty.vue) | Vue | 69 | 0 | 0 | 69 |
| [pages/product/_productid.vue](/pages/product/_productid.vue) | Vue | 88 | 0 | 2 | 90 |
| [pages/product/index.vue](/pages/product/index.vue) | Vue | 70 | 0 | 1 | 71 |
| [static/vuetify-logo.svg](/static/vuetify-logo.svg) | XML | 1 | 0 | 1 | 2 |
| [store/README.md](/store/README.md) | Markdown | 6 | 0 | 5 | 11 |
| [store/index.js](/store/index.js) | JavaScript | 211 | 0 | 26 | 237 |

[summary](results.md) / details / [diff summary](diff.md) / [diff details](diff-details.md)