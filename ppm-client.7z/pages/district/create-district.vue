<template>
  <div>
    <v-container>
      <!-- <card>
    <h5 slot="header" class="title">Edit Profile</h5>
    <div class="row">
      <div class="col-md-5 pr-md-1">
        <v-textField 
          label="Company"
                  placeholder="Company"
                  v-model="company"
                  disabled>
        </v-textField>
      </div>
      <div class="col-md-3 px-md-1">
        <v-textField label="Username"
                  placeholder="Username"
                  v-model=" username">
        </v-textField>
      </div>
      <div class="col-md-4 pl-md-1">
        <v-textField label="Email address"
                  type="email"
                  placeholder="mike@email.com">
        </v-textField>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 pr-md-1">
        <v-textField label="First Name"
                  v-model=" firstName"
                  placeholder="First Name">
        </v-textField>
      </div>
      <div class="col-md-6 pl-md-1">
        <v-textField label="Last Name"
                  v-model=" lastName"
                  placeholder="Last Name">
        </v-textField>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <v-textField label="Address"
                  v-model=" address"
                  placeholder="Home Address">
        </v-textField>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4 pr-md-1">
        <v-textField label="City"
                  v-model=" city"
                  placeholder="City">
        </v-textField>
      </div>
      <div class="col-md-4 px-md-1">
        <v-textField label="Country"
                  v-model=" country"
                  placeholder="Country">
        </v-textField>
      </div>
      <div class="col-md-4 pl-md-1">
        <v-textField label="Postal Code"
                  placeholder="ZIP Code">
        </v-textField>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8">
        <v-textField>
          <label>About Me</label>
          <v-textarea 
          rows="4" cols="80"
                    class="form-control"
                    placeholder="Here can be your description"
                    v-model=" about">

              </v-textarea>
        </v-textField>
      </div>
    </div>
    <v-button slot="footer" type="primary" fill>Save</v-button>
  </card> -->

      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create District</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Enter Code"
                  v-model="district"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Enter Name"
                  type="text"
                  v-model="name"
                ></v-textField>
              </v-col>
            </v-row>

            <v-btn color="primary" type="submit">Save</v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      district: "",
      name: "",
    };
  },
  methods: {
    ...mapActions(["createDistrict"]),
    create() {
      if (!this.district || !this.name) {
        alert("Please fill all the field");
      } else {
        const data = {
          district: this.district,
          name: this.name,
        };
        this.createDistrict(data);
      }
    },
  },
};
</script>
<style>
#w-100 {
  width: 100%;
}
.text-center {
  text-align: center !important;
}
</style>