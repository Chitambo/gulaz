<template >
  <div>
    <v-container>
      <v-simple-table dark>
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-left">Id</th>
              <th class="text-left">Code</th>
              <th class="text-left">Name</th>
              <th class="text-left">Edit</th>
              <th class="text-left">Delete</th>
            </tr>
          </thead>
          <tbody v-if="$store.state.districts.length > 0">
            <tr v-for="district in $store.state.districts" :key="district.id">
              <td>{{ district.id }}</td>
              <td>{{ district.DISTRICT }}</td>
              <td>{{ district.NAME }}</td>
              <td>
                <nuxt-link
                  :to="{
                    name: 'district-districtid',
                    path: 'district/:id',
                    params: { districtid: district.id },
                  }"
                  ><v-btn class="secondary">Edit</v-btn></nuxt-link
                >
              </td>
              <td>
                <v-btn @click="deleteDistrict(district.id)" class="error"
                  >Delete</v-btn
                >
              </td>
            </tr>
          </tbody>
          <tbody v-else>
            <h3>Record Not Found</h3>
          </tbody>
        </template>
      </v-simple-table>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],

  methods: {
    ...mapActions(["getAllDistrict"]),
    ...mapActions(["deleteDistrict"]),
    deleteDistrict(id) {
      const data = {
        id: id,
      };
      this.deleteDistrict(data);
      this.getAlldistrict();
    },
  },
  mounted() {
    this.getAllDistrict();
  },
};
</script>
<style >
</style>