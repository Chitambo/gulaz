<template>
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create Bank</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Bank Code"
                  v-model="bankcode"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col>
                <v-textField
                  label="Bank Name"
                  type="text"
                  v-model="bankname"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 1"
                  type="text"
                  v-model="addr1"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 2"
                  type="text"
                  v-model="addr2"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 3"
                  type="text"
                  v-model="addr3"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6"> </v-col>
            </v-row>

            <v-btn color="primary" type="submit">Save</v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      bankcode: "",
      bankname: "",
      addr1: "",
      addr2: "",
      addr3: "",
    };
  },
  methods: {
    ...mapActions(["createBank"]),
    create() {
      if (!this.bankcode || !this.bankname || !this.addr1) {
        alert("Please fill all the field");
      } else {
        const data = {
          bankcode: this.bankcode,
          bankname: this.bankname,
          addr1: this.addr1,
          addr2: this.addr2,
          addr3: this.addr3,
        };
        this.createBank(data);
      }
    },
  },
};
</script>
<style>
#w-100 {
  width: 100%;
}
.text-center {
  text-align: center !important;
}
</style>