<template>
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create Pensioner</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <v-tabs vertical>
              <v-tab>
                <v-icon left> mdi-account </v-icon>
                Peronal
              </v-tab>
              <v-tab>
                <v-icon left> mdi-umbrella </v-icon>
                Pension
              </v-tab>
              <v-tab>
                <v-icon left> mdi-account-multiple </v-icon>
                Spouse
              </v-tab>

              <v-tab-item>
                <v-card flat>
                  <v-card-text>
                    <v-row justify="center" align="center">
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="*Staff Number"
                          v-model="staffno"
                          type="text"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="*Names"
                          v-model="name"
                          type="text"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="*Enter NRC Number"
                          type="text"
                          v-model="nrcno"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Address 1"
                          type="text"
                          v-model="addr1"
                        ></v-textField>
                      </v-col>
                    </v-row>

                    <v-row justify="center" align="center">
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Address 2"
                          v-model="addr2"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Address 3"
                          v-model="addr3"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Bank Code"
                          v-model="bankcode"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Bank Account Number"
                          v-model="bank_a_no"
                          type="text"
                        ></v-textField>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </v-card>
              </v-tab-item>
              <v-tab-item>
                <v-card flat>
                  <v-card-text>
                    <v-row>
                      <v-col cols="12" sm="8" md="6">
                        <v-autocomplete
                          ref="pay_stat"
                          v-model="pay_stat"
                          :items="paymethods"
                          label="Payment Methods"
                          placeholder="Select..."
                        ></v-autocomplete>

                        <!-- <v-textField
                          label="Bank Account Number"
                          v-model="bank_a_no"
                          type="text"
                        ></v-textField> -->
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Pay Point Code"
                          v-model="district"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Town Name"
                          v-model="status2"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Guarantee Period"
                          v-model="g_period"
                          type="number"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Spouse Pension"
                          v-model="s_pension"
                          suffix="%"
                          type="text"
                          value="0"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Annual Pension"
                          v-model="pen_amt"
                          type="text"
                          value="0"
                          prefix="ZMW"
                          required
                          hint="*required"
                        ></v-textField>

                        <!-- <v-textField
                          label="Spouse Name"
                          v-model="s_name"
                          type="text"
                        ></v-textField> -->
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Payment Frequency"
                          v-model="pay_freq"
                          value="1"
                          type="number"
                          required
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Amount paid Todate"
                          v-model="amt_todate"
                          value="0.00"
                          prefix="ZMW"
                          type=""
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Commencment Date"
                          v-model="st_date"
                          type="date"
                          :return-value.sync="date"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Next Payment Date"
                          v-model="nextdate"
                          type="date"
                          required
                        ></v-textField>
                      </v-col>
                    </v-row>
                  </v-card-text>
                </v-card>
              </v-tab-item>
              <v-tab-item>
                <v-card flat>
                  <v-card-text>
                    <v-row>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Spouse Name"
                          v-model="s_name"
                          type="text"
                        ></v-textField>

                        <!-- <v-textField
                          label="Annual Pension"
                          v-model="pen_amt"
                          type="text"
                        ></v-textField> -->
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Spouse NRC Number"
                          v-model="s_nrcno"
                          type="text"
                        ></v-textField>
                      </v-col>
                      <!-- <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Payment Frequency"
                          v-model="pay_freq"
                          type="number"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Amount paid Todate"
                          v-model="amt_todate"
                          value="0.00"
                          prefix="ZMW"
                          type=""
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Commencment Date"
                          v-model="st_date"
                          type="date"
                        ></v-textField>
                      </v-col>
                      <v-col cols="12" sm="8" md="6">
                        <v-textField
                          label="Next Payment Date"
                          v-model="nextdate"
                          type="date"
                        ></v-textField>
                      </v-col> -->
                    </v-row>
                  </v-card-text>
                </v-card>
              </v-tab-item>
            </v-tabs>

            <!-- <v-btn color="primary" type="submit">Save</v-btn> -->
            <v-btn
              color="primary"
              class="mr-4"
              type="submit"
              :disabled="invalid"
            >
              submit
            </v-btn>
            <v-btn @click="clear"> clear </v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      paymethods: ["Cheque", "Cash", "Bank"],
      nrcno: "",
      staffno: "",
      name: "",
      addr1: "",
      addr2: "",
      addr3: "",
      bankcode: "",
      bank_a_no: "",
      pay_freq: "0",
      g_period: "0",
      s_pension: "",
      s_name: "",
      s_nrcno: "",
      // dod: "",
      // s_dod: "",
      scode: "",
      pay_stat: "",
      st_date: "",
      nextdate: "",
      endg_date: "",
      pen_amt: "0.00",
      amt_todate: "0.00",
      //mon_pay: "",
      status1: "",
      status2: "",
      status3: "",
      status4: "",
      district: "",
      PriCurr:"ZMW"
    };
  },
  methods: {
    ...mapActions(["createDetail"]),
    create() {
      if (!this.nrcno || !this.staffno || !this.name) {
        alert("Please fill all required fields *");
      } else {
        const data = {
          date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
          nrcno: this.nrcno,
          staffno: this.staffno,
          name: this.name,
          addr1: this.addr1,
          addr2: this.addr2,
          addr3: this.addr3,
          bankcode: this.bankcode,
          bank_a_no: this.bank_a_no,
          pay_freq: this.pay_freq,
          g_period: this.g_period,
          s_pension: this.s_pension,
          s_name: this.s_name,
          s_nrcno: this.s_nrcno,
          //  dod : this.dod,
          //  s_dod : this.s_dod,
          scode: this.scode,
          pay_stat: this.pay_stat,
          st_date: this.st_date,
          nextdate: this.nextdate,
          endg_date: this.endg_date,
          pen_amt: this.pen_amt,
          amt_todate: this.amt_todate,
          //mon_pay: this.mon_pay,
          status1: this.status1,
          status2: this.status2,
          status3: this.status3,
          status4: this.status4,
          district: this.district,
        };
        this.createDetail(data);
      }
    },
  },
};
</script>
<style>
#w-100 {
  width: 100%;
}
.text-center {
  text-align: center !important;
}
</style>