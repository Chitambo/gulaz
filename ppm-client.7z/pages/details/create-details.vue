<template>
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create Pensioner</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <v-card flat>
              <v-card-text>
                <div class="row">
                  <div class="col-md-3 pr-md-1">
                    <v-textField
                      label="*Staff Number"
                      v-model="staffno"
                      required
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-6 px-md-1">
                    <v-textField label="*Names" v-model="name" required>
                    </v-textField>
                  </div>
                  <div class="col-md-3 pl-md-1">
                    <v-textField
                      label="*Enter NRC Number"
                      v-model="nrcno"
                      type="nrcno"
                      required
                    >
                    </v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-textField label="Address 1" v-model="addr1">
                    </v-textField>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-textField label="Address 2" v-model="addr2">
                    </v-textField>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-textField label="*Address 3" v-model="addr3">
                    </v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-textField label="Bank Code" v-model="bankcode">
                    </v-textField>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-textField
                      label="Bank Account Number"
                      v-model="bank_a_no"
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-autocomplete
                      ref="pay_stat"
                      v-model="pay_stat"
                      :items="paymethods"
                      label="Payment Methods"
                      placeholder="Select..."
                    ></v-autocomplete>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-autocomplete
                      ref="pay_stat"
                      v-model="pay_stat"
                      :items="paymethods"
                      label="Payment Methods"
                      placeholder="Select..."
                    ></v-autocomplete>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-select
                      v-model="select"
                      :hint="`${select.DISTRICT}, ${select.NAME}`"
                      :items="paypoint"
                      item-text="NAME"
                      item-value="paypoint.DISTRICT"
                      label="Paypoint"
                      persistent-hint
                      return-object
                      single-line
                    ></v-select>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-textField
                      label="Town Name"
                      v-model="status2"
                      type="text"
                    ></v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-2 pr-md-1">
                    <v-textField
                      label="Guarantee Period"
                      v-model="g_period"
                      type="number"
                      required
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-2 px-md-1">
                    <v-textField
                      label="Spouse Pension"
                      v-model="s_pension"
                      suffix="%"
                      type="text"
                      value="0"
                      required
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Pension Amount"
                      v-model="pen_amt"
                      type="text"
                      value="0"
                      prefix="ZMW"
                      required
                      hint="*required"
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Payment Frequency"
                      v-model="pay_freq"
                      value="1"
                      type="number"
                      required
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Commencment Date"
                      v-model="st_date"
                      type="date"
                      :return-value.sync="date"
                    ></v-textField>
                  </div>

                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Next Payment Date"
                      v-model="nextdate"
                      type="date"
                      required
                    ></v-textField>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3 pr-md-1">
                    <v-textField label="*Spouse Name" v-model="s_name">
                    </v-textField>
                  </div>
                  <div class="col-md-6 px-md-1">
                    <v-textField
                      label="Spouse NRC Number"
                      v-model="s_nrcno"
                      type="text"
                    ></v-textField>
                  </div>
                </div>
              </v-card-text>
            </v-card>

            <!-- <v-btn color="primary" type="submit">Save</v-btn> -->
            <v-btn
              color="primary"
              class="mr-4"
              type="submit"
              
            >
              submit
            </v-btn>
            <v-btn @click="clear"> clear </v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      select: { DISTRICT: "", NAME: "" },
      paypoint: [],
      paymethods: ["Cheque", "Cash", "Bank"],
      nrcno: "",
      staffno: "",
      name: "",
      addr1: "",
      addr2: "",
      addr3: "",
      bankcode: "",
      bank_a_no: "",
      pay_freq: "1",
      g_period: "0",
      s_pension: "",
      s_name: "",
      s_nrcno: "",
      // dod: "",
      // s_dod: "",
      scode: "",
      pay_stat: "",
      st_date: "",
      nextdate: "",
      endg_date: "",
      pen_amt: "0.00",
      amt_todate: "0.00",
      //mon_pay: "",
      status1: "",
      status2: "",
      status3: "",
      status4: "",
      district: "",
      PriCurr: "ZMW",
    };
  },
  methods: {
    ...mapActions(["createDetail"]),
    create() {
      if (!this.nrcno || !this.staffno || !this.name || !this.nextdate) {
        alert("Please fill all required fields *");
      } else {
        const data = {
          // date: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
          //   .toISOString()
          //   .substr(0, 10),
          nrcno: this.nrcno,
          staffno: this.staffno,
          name: this.name,
          addr1: this.addr1,
          addr2: this.addr2,
          addr3: this.addr3,
          bankcode: this.bankcode,
          bank_a_no: this.bank_a_no,
          pay_freq: this.pay_freq,
          g_period: this.g_period,
          s_pension: this.s_pension,
          s_name: this.s_name,
          s_nrcno: this.s_nrcno,
          //  dod : this.dod,
          //  s_dod : this.s_dod,
          scode: this.scode,
          pay_stat: this.pay_stat,
          st_date: this.st_date,
          nextdate: this.nextdate,
          endg_date: this.endg_date,
          pen_amt: this.pen_amt,
          amt_todate: this.amt_todate,
          //mon_pay: this.mon_pay,
          status1: this.status1,
          status2: this.status2,
          status3: this.status3,
          status4: this.status4,
          district: this.district,
        };
        this.createDetail(data);
      }
    },

    async getPaypoints() {
      const res = await this.$axios.get(
        "http://localhost/ppm/ppm-server/crud-districts/get-all-districts.php"
      );
      if (res.data.status == 1) {
        this.paypoint = res.data.message;
        console.log(res.data.message);
      }
    },
  },

  mounted() {
    this.getPaypoints();
  },
};
</script>
<style>
#w-100 {
  width: 100%;
}
.text-center {
  text-align: center !important;
}
</style>