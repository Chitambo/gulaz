<template>
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create Pensioner</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Staff Number"
                  v-model="staffno"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Names"
                  v-model="name"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Enter NRC Number"
                  type="text"
                  v-model="nrcno"
                ></v-textField>
              </v-col>

              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 1"
                  type="text"
                  v-model="addr1"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 2"
                  v-model="addr2"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 3"
                  v-model="addr3"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-autocomplete
                  ref="pay_stat"
                  v-model="pay_stat"
                  :items="paymethods"
                  label="Payment Methods"
                  placeholder="Select..."
                
                ></v-autocomplete>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Bank Code"
                  v-model="bankcode"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Bank Account Number"
                  v-model="bank_a_no"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Pay Point Code"
                  v-model="status1"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Town Name"
                  v-model="status2"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Guarantee Period"
                  v-model="g_period"
                  type="number"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse Pension"
                  v-model="s_pension"
                  suffix="%"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse Name"
                  v-model="s_name"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Annual Pension"
                  v-model="pen_amt"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse NRC Number"
                  v-model="s_nrcno"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Payment Frequency"
                  v-model="pay_freq"
                  type="number"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Amount paid Todate"
                  v-model="amt_todate"
                  value="0.00"
                  prefix="ZMW"
                  type=""
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Commencment Date"
                  v-model="st_date"
                  type="date"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Next Payment Date"
                  v-model="nextdate"
                  type="date"
                ></v-textField>
              </v-col>
            </v-row>
            <v-btn color="primary" type="submit">Save</v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      paymethods: ["Cheque", "Cash", "Bank"],
      nrcno: "",
      staffno: "",
      name: "",
      addr1: "",
      addr2: "",
      addr3: "",
      bankcode: "",
      bank_a_no: "",
      pay_freq: "",
      g_period: "",
      s_pension: "",
      s_name: "",
      s_nrcno: "",
      dod: "",
      s_dod: "",
      scode: "",
      pay_stat: "",
      st_date: "",
      nextdate: "",
      endg_date: "",
      pen_amt: "",
      amt_todate: "",
      mon_pay: "",
      status1: "",
      status2: "",
      status3: "",
      status4: "",
      district: "",
    };
  },
  methods: {
    ...mapActions(["createDetail"]),
    create() {
      if (!this.nrcno || !this.staffno || !this.name) {
        alert("Please fill all the field");
      } else {
        const data = { 
     nrcno : this.nrcno,
     staffno : this.staffno,
     name : this.name,
     addr1 : this.addr1,
     addr2 : this.addr2,
     addr3 : this.addr3,
     bankcode : this.bankcode,
    //  bank_a_no : this.bank_a_no,
    //  pay_freq : this.pay_freq,
    //  g_period : this.g_period,
    //  s_pension : this.s_pension,
    //  s_name : this.s_name,
    //  s_nrcno : this.s_nrcno,
    //  dod : this.dod,
    //  s_dod : this.s_dod,
    //  scode : this.scode,
    //  pay_stat : this.pay_stat,
    //  st_date : this.st_date,
    //  nextdate : this.nextdate,
    //  endg_date : this.endg_date,
    //  pen_amt : this.pen_amt,
    //  amt_todate : this.amt_todate,
    //  mon_pay : this.mon_pay,
    //  status1 : this.status1,
    //  status2 : this.status2,
    //  status3 : this.status3,
    //  status4 : this.status4,
    //  district : this.district,
        };
        this.createDetail(data);
      }
    },
  },
};
</script>
<style>
#w-100 {
  width: 100%;
}
.text-center {
  text-align: center !important;
}
</style>