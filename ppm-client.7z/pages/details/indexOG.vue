<template >
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <span class="title">Pensioners </span>

          <v-spacer></v-spacer>
          <div>
            <v-btn elevation="4" class="blue-grey mr-2" fab small dark>
              <v-icon>mdi-magnify</v-icon>
            </v-btn>
            <v-btn
              elevation="4"
              class="brown lighten-1 mr-2"
              fab
              small
              dark
              @click="getAllDetails()"
            >
              <v-icon>mdi-refresh</v-icon>
            </v-btn>
            <v-btn elevation="4" class="teal darken-2 mr-2" fab small dark>
              <v-icon>mdi-printer</v-icon>
            </v-btn>
            <v-btn
              elevation="4"
              class="deep-orange darken-3"
              fab
              small
              dark
              nuxt-link
              to="/details/create-details"
            >
              <v-icon>mdi-plus</v-icon>
            </v-btn>
          </div>
        </v-card-title>

        <!-- <v-btn depressed color="primary" @click="calc(($month = 1))">
          Calculate
        </v-btn> -->

        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field>
      </v-card>
    </v-container>

    <v-container>
      <!-- <v-pagination v-model="page" :length="6"></v-pagination> -->
      <v-simple-table dark>
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-left">Staff No</th>
              <th class="text-left">Name</th>
              <th class="text-left">NRC NO</th>
              <th class="text-left">Next date</th>
              <th class="text-left">Edit</th>
              <!-- <th class="text-left">Delete</th> -->
            </tr>
          </thead>
          <tbody v-if="$store.state.details.length > 0">
            <tr v-for="detail in $store.state.details" :key="detail.id">
              <td>{{ detail.STAFF_NO }}</td>
              <td>{{ detail.NAME }}</td>
              <td>{{ detail.NRCNO }}</td>
              <td>{{ detail.NEXTDATE }}</td>
              <td>
 
            <!-- <v-btn
              elevation="4"
              class="secondary"
            
              nuxt-link
              to="/details/create-details"
            params=id: detail.id 

            >
             Edit
            </v-btn> -->
                <nuxt-link
                  :to="{

                    path: '/details/:detailsid',
                    params: {detailsid: detail.id }
                  }"
                  ><v-btn class="secondary">Edit</v-btn></nuxt-link
                >
                <!-- <v-btn @click="editDetails(detail.id)" class="secondary"
                  >Edit</v-btn
                > -->
              </td>
              <td>
                <!-- <v-btn @click="deleteDet(detail.id)" class="error"
                  >Delete</v-btn
                > -->
              </td>
            </tr>
          </tbody>
          <tbody v-else>
            <h3>Record Not Found</h3>
          </tbody>
        </template>
      </v-simple-table>

    </v-container>
  </div>
</template>
<script>
import { mapActions, Store } from "vuex";
export default {
  middleware: ["auth"],
  data () {
      return {
        search: '',
        trans:[],
       
       
      }
    },

  methods: {
    ...mapActions(["getAllDetails"]),
    ...mapActions(["deleteDetails"]),
    // ...mapActions(["calculate"]),

  
    deleteDet(id) {
      const data = {
        id: id,
      };

      this.deleteDetails(data);
      this.getAllDetails();
    },

    getitDet() {
 
      // this.trans= Response.data.message;
      this.getAllDetails();
      // this.trans= Store.data.message;
    },


    getDisplayTrans(trans) {
      return {
        STAFF_NO: trans.STAFF_NO,
        NAME: trans.NAME,
        NRCNO: trans.NRCNO,
        NEXTDATE: trans.NEXTDATE,
      };
    },
    editDetails(id) {
      // let route = this.$router.resolve({ path: "/contact" });
      // let routeData = this.$router.resolve({
      //   name: "detail-detailid",
      //   path: "/details/:detailsid",
      //   params: { detailsid: id },
      // });


      // this.$router.push({
      //   name: "detail-detailid",
      //   path: "/details/:detailsid",
      //   params: { detailsid: id },
      // });

      this.$router.push({ name: 'detail-detailsid', path: "/details/_detailsid", params: {id} })
      //alert(document.getElementById("example").textContent)
      alert(id);
     
//this.$router.push({ path: 'create-details'})
      // router.push({ path: '/create-details', hash: '#team' })
      // open(routeData.href);
    },
    
    // calc(month) {
    //   const data = {
    //     month: month,
    //   };
    //   this.calculate(data);
    // },
  },
  mounted() {
    // this.getAllDetails();
    this.getitDet();
  },
};
</script>
<style >
</style>