<template>
  <div>
    <v-container>
      <v-card>
        <v-card-title>
          <h1 class="my-4 text-center">Create Pensioner</h1>
          <form action="" id="w-100" @submit.prevent="create">
            <!-- <v-row justify="center" align="center">
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Staff Number"
                  v-model="staffno"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Names"
                  v-model="name"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Enter NRC Number"
                  type="text"
                  v-model="nrcno"
                ></v-textField>
              </v-col>

              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 1"
                  type="text"
                  v-model="addr1"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 2"
                  v-model="addr2"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Address 3"
                  v-model="addr3"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-autocomplete
                  ref="pay_stat"
                  v-model="pay_stat"
                  :items="paymethods"
                  label="Payment Methods"
                  placeholder="Select..."
                
                ></v-autocomplete>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Bank Code"
                  v-model="bankcode"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Bank Account Number"
                  v-model="bank_a_no"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Pay Point Code"
                  v-model="status1"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Town Name"
                  v-model="status2"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Guarantee Period"
                  v-model="g_period"
                  type="number"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse Pension"
                  v-model="s_pension"
                  suffix="%"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse Name"
                  v-model="s_name"
                  type="text"
                ></v-textField>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Annual Pension"
                  v-model="pen_amt"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Spouse NRC Number"
                  v-model="s_nrcno"
                  type="text"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Payment Frequency"
                  v-model="pay_freq"
                  type="number"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Amount paid Todate"
                  v-model="amt_todate"
                  value="0.00"
                  prefix="ZMW"
                  type=""
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Commencment Date"
                  v-model="st_date"
                  type="date"
                ></v-textField>
              </v-col>
              <v-col cols="12" sm="8" md="6">
                <v-textField
                  label="Next Payment Date"
                  v-model="nextdate"
                  type="date"
                ></v-textField>
              </v-col>
            </v-row> -->

            <v-card flat>
              <v-card-text>
                <div class="row">
                  <div class="col-md-3 pr-md-1">
                    <v-textField
                      label="*Staff Number"
                      v-model="staffno"
                      required
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-6 px-md-1">
                    <v-textField label="*Names" v-model="name" required>
                    </v-textField>
                  </div>
                  <div class="col-md-3 pl-md-1">
                    <v-textField
                      label="*Enter NRC Number"
                      type="nrcno"
                      required
                    >
                    </v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-textField label="Address 1" v-model="addr1">
                    </v-textField>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-textField label="Address 2" v-model="addr2">
                    </v-textField>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-textField label="*Address 3" type="addr3" required>
                    </v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-textField label="Bank Code" v-model="bankcode">
                    </v-textField>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-textField
                      label="Bank Account Number"
                      v-model="bank_a_no"
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-autocomplete
                      ref="pay_stat"
                      v-model="pay_stat"
                      :items="paymethods"
                      label="Payment Methods"
                      placeholder="Select..."
                    ></v-autocomplete>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4 pr-md-1">
                    <v-autocomplete
                      ref="pay_stat"
                      v-model="pay_stat"
                      :items="paymethods"
                      label="Payment Methods"
                      placeholder="Select..."
                    ></v-autocomplete>
                  </div>
                  <div class="col-md-4 px-md-1">
                    <v-select
                      v-model="select"
                      :hint="`${select.DISTRICT}, ${select.NAME}`"
                      :items="paypoint"
                      item-text="NAME"
                      item-value="paypoint.DISTRICT"
                      label="Paypoint"
                      persistent-hint
                      return-object
                      single-line
                    ></v-select>
                  </div>
                  <div class="col-md-4 pl-md-1">
                    <v-textField
                      label="Town Name"
                      v-model="status2"
                      type="text"
                    ></v-textField>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-2 pr-md-1">
                    <v-textField
                      label="Guarantee Period"
                      v-model="g_period"
                      type="number"
                      required
                    >
                    </v-textField>
                  </div>
                  <div class="col-md-2 px-md-1">
                    <v-textField
                      label="Spouse Pension"
                      v-model="s_pension"
                      suffix="%"
                      type="text"
                      value="0"
                      required
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Pension Amount"
                      v-model="pen_amt"
                      type="text"
                      value="0"
                      prefix="ZMW"
                      required
                      hint="*required"
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Payment Frequency"
                      v-model="pay_freq"
                      value="1"
                      type="number"
                      required
                    ></v-textField>
                  </div>
                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Commencment Date"
                      v-model="st_date"
                      type="date"
                      :return-value.sync="date"
                    ></v-textField>
                  </div>

                  <div class="col-md-2 pl-md-1">
                    <v-textField
                      label="Next Payment Date"
                      v-model="nextdate"
                      type="date"
                      required
                    ></v-textField>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3 pr-md-1">
                    <v-textField label="*Spouse Name" v-model="s_name">
                    </v-textField>
                  </div>
                  <div class="col-md-6 px-md-1">
                    <v-textField
                      label="Spouse NRC Number"
                      v-model="s_nrcno"
                      type="text"
                    ></v-textField>
                  </div>
                </div>
              </v-card-text>
            </v-card>

            <v-btn color="primary" type="submit">Save</v-btn>
          </form>
        </v-card-title>
      </v-card>
    </v-container>
  </div>
</template>
<script>
import { mapActions } from "vuex";
export default {
  middleware: ["auth"],
  data() {
    return {
      select: { DISTRICT: "", NAME: "" },
      paypoint: [],
      paymethods: ["Cheque", "Cash", "Bank"],
      nrcno: "",
      staffno: "",
      name: "",
      addr1: "",
      addr2: "",
      addr3: "",
      bankcode: "",
      bank_a_no: "",
      pay_freq: "0",
      g_period: "0",
      s_pension: "",
      s_name: "",
      s_nrcno: "",
      // dod: "",
      // s_dod: "",
      scode: "",
      pay_stat: "",
      st_date: "",
      nextdate: "",
      endg_date: "",
      pen_amt: "0.00",
      amt_todate: "0.00",
      //mon_pay: "",
      status1: "",
      status2: "",
      status3: "",
      status4: "",
      district: "",
    };
  },

  methods: {
    async getDetailsById() {
      const data = {
        id: 1,
        // id: this.$route.params.detailsid
      };

      // alert(data.id);
      const res = await this.$axios.get(
        "http://localhost/ppm/ppm-server/crud-details.php/get-single-detail.php",
        // "http://localhost/ppm/ppm-server/crud-details.php/get-details-id.php",
        data
      );
      if (res.data.status == 1) {
        // this.paymethods= res.data.message[0].paymethods;
        this.nrcno = res.data.message[0].NRCNO;
        this.staffno = res.data.message[0].STAFF_NO;
        this.name = res.data.message[0].NAME;
        this.addr1 = res.data.message[0].ADDR1;
        this.addr2 = res.data.message[0].ADDR2;
        this.addr3 = res.data.message[0].ADDR3;
        this.bankcode = res.data.message[0].BANKCODE;
        this.bank_a_no = res.data.message[0].BANK_A_NO;
        this.pay_freq = res.data.message[0].PAY_FREQ;
        this.g_period = res.data.message[0].G_PERIOD;
        this.s_pension = res.data.message[0].S_PENSION;
        this.s_name = res.data.message[0].S_NAME;
        this.s_nrcno = res.data.message[0].S_NRCNO;
        // dod: "",
        // s_dod: "",
        this.scode = res.data.message[0].SCODE;
        this.pay_stat = res.data.message[0].PAY_STAT;
        this.st_date = res.data.message[0].ST_DATE;
        this.nextdate = res.data.message[0].NEXTDATE;
        this.endg_date = res.data.message[0].ENDG_DATE;
        this.pen_amt = res.data.message[0].PEN_AMT;
        this.amt_todate = res.data.message[0].AMT_TODATE;
        //mon_pay: "",
        this.status1 = res.data.message[0].STATUS1;
        this.status2 = res.data.message[0].STATUS1;
        this.status3 = res.data.message[0].STATUS1;
        this.status4 = res.data.message[0].STATUS1;
        this.district = res.data.message[0].district;
        // alert(this.name);
      } else {
        alert("bad Call");
      }
    },

    ...mapActions(["updateDetails"]),
    updateDetails() {
      if (!this.staffno || !this.name || !this.nrc) {
        alert("Please Fill the Field");
      } else {
        const data = {
          nrcno: this.nrcno,
          staffno: this.staffno,
          name: this.name,
          addr1: this.addr1,
          addr2: this.addr2,
          addr3: this.addr3,
        };
        this.updateDetails(data);
      }
    },

      async getPaypoints() {
      const res = await this.$axios.get(
        "http://localhost/ppm/ppm-server/crud-districts/get-all-districts.php"
      );
      if (res.data.status == 1) {
        this.paypoint = res.data.message;
        console.log(res.data.message);
      }
    },
  },
  mounted() {
    this.getDetailsById();
    this.getPaypoints();
  },
};
</script>
<style>
</style>