import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0a61711b = () => interopDefault(import('..\\pages\\banks\\index.vue' /* webpackChunkName: "pages/banks/index" */))
const _5c3e19b0 = () => interopDefault(import('..\\pages\\details\\index.vue' /* webpackChunkName: "pages/details/index" */))
const _6ee55554 = () => interopDefault(import('..\\pages\\district\\index.vue' /* webpackChunkName: "pages/district/index" */))
const _f923dbce = () => interopDefault(import('..\\pages\\Login.vue' /* webpackChunkName: "pages/Login" */))
const _42fa474c = () => interopDefault(import('..\\pages\\Loginxy.vue' /* webpackChunkName: "pages/Loginxy" */))
const _1e0aa778 = () => interopDefault(import('..\\pages\\parameters\\index.vue' /* webpackChunkName: "pages/parameters/index" */))
const _e62c7e3a = () => interopDefault(import('..\\pages\\product\\index.vue' /* webpackChunkName: "pages/product/index" */))
const _3655cbda = () => interopDefault(import('..\\pages\\reports\\index.vue' /* webpackChunkName: "pages/reports/index" */))
const _18683cdd = () => interopDefault(import('..\\pages\\scheme\\index.vue' /* webpackChunkName: "pages/scheme/index" */))
const _0445ca2b = () => interopDefault(import('..\\pages\\Securites\\index.vue' /* webpackChunkName: "pages/Securites/index" */))
const _a587e4c2 = () => interopDefault(import('..\\pages\\settings\\index.vue' /* webpackChunkName: "pages/settings/index" */))
const _36ae1e18 = () => interopDefault(import('..\\pages\\Signup.vue' /* webpackChunkName: "pages/Signup" */))
const _bb5eebfa = () => interopDefault(import('..\\pages\\Signupk.vue' /* webpackChunkName: "pages/Signupk" */))
const _3803512d = () => interopDefault(import('..\\pages\\transactions\\index.vue' /* webpackChunkName: "pages/transactions/index" */))
const _a3290fac = () => interopDefault(import('..\\pages\\users\\index.vue' /* webpackChunkName: "pages/users/index" */))
const _62a2316d = () => interopDefault(import('..\\pages\\banks\\create-banks.vue' /* webpackChunkName: "pages/banks/create-banks" */))
const _67bca403 = () => interopDefault(import('..\\pages\\details\\create-details.vue' /* webpackChunkName: "pages/details/create-details" */))
const _0f588dbc = () => interopDefault(import('..\\pages\\details\\create-details copy.vue' /* webpackChunkName: "pages/details/create-details copy" */))
const _d84feaf4 = () => interopDefault(import('..\\pages\\details\\create-detailsy.vue' /* webpackChunkName: "pages/details/create-detailsy" */))
const _4bd10c48 = () => interopDefault(import('..\\pages\\details\\index - Copy.vue' /* webpackChunkName: "pages/details/index - Copy" */))
const _665fa507 = () => interopDefault(import('..\\pages\\details\\index - Copy (2).vue' /* webpackChunkName: "pages/details/index - Copy (2)" */))
const _7ab81188 = () => interopDefault(import('..\\pages\\details\\indexOG.vue' /* webpackChunkName: "pages/details/indexOG" */))
const _267582c1 = () => interopDefault(import('..\\pages\\district\\create-district.vue' /* webpackChunkName: "pages/district/create-district" */))
const _4c49865d = () => interopDefault(import('..\\pages\\product\\Create-Product.vue' /* webpackChunkName: "pages/product/Create-Product" */))
const _40e7736c = () => interopDefault(import('..\\pages\\product\\Create-Producty.vue' /* webpackChunkName: "pages/product/Create-Producty" */))
const _7f56b5ab = () => interopDefault(import('..\\pages\\reports\\summery.vue' /* webpackChunkName: "pages/reports/summery" */))
const _109646cc = () => interopDefault(import('..\\pages\\banks\\_banksid.vue' /* webpackChunkName: "pages/banks/_banksid" */))
const _4b642d20 = () => interopDefault(import('..\\pages\\details\\_detailsid.vue' /* webpackChunkName: "pages/details/_detailsid" */))
const _0849d4ca = () => interopDefault(import('..\\pages\\district\\_districtid.vue' /* webpackChunkName: "pages/district/_districtid" */))
const _96cda1ec = () => interopDefault(import('..\\pages\\product\\_productid.vue' /* webpackChunkName: "pages/product/_productid" */))
const _42544f22 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/banks",
    component: _0a61711b,
    name: "banks"
  }, {
    path: "/details",
    component: _5c3e19b0,
    name: "details"
  }, {
    path: "/district",
    component: _6ee55554,
    name: "district"
  }, {
    path: "/Login",
    component: _f923dbce,
    name: "Login"
  }, {
    path: "/Loginxy",
    component: _42fa474c,
    name: "Loginxy"
  }, {
    path: "/parameters",
    component: _1e0aa778,
    name: "parameters"
  }, {
    path: "/product",
    component: _e62c7e3a,
    name: "product"
  }, {
    path: "/reports",
    component: _3655cbda,
    name: "reports"
  }, {
    path: "/scheme",
    component: _18683cdd,
    name: "scheme"
  }, {
    path: "/Securites",
    component: _0445ca2b,
    name: "Securites"
  }, {
    path: "/settings",
    component: _a587e4c2,
    name: "settings"
  }, {
    path: "/Signup",
    component: _36ae1e18,
    name: "Signup"
  }, {
    path: "/Signupk",
    component: _bb5eebfa,
    name: "Signupk"
  }, {
    path: "/transactions",
    component: _3803512d,
    name: "transactions"
  }, {
    path: "/users",
    component: _a3290fac,
    name: "users"
  }, {
    path: "/banks/create-banks",
    component: _62a2316d,
    name: "banks-create-banks"
  }, {
    path: "/details/create-details",
    component: _67bca403,
    name: "details-create-details"
  }, {
    path: "/details/create-details%20copy",
    component: _0f588dbc,
    name: "details-create-details copy"
  }, {
    path: "/details/create-detailsy",
    component: _d84feaf4,
    name: "details-create-detailsy"
  }, {
    path: "/details/index%20-%20Copy",
    component: _4bd10c48,
    name: "details-index - Copy"
  }, {
    path: "/details/index%20-%20Copy%20(2)",
    component: _665fa507,
    name: "details-index - Copy (2)"
  }, {
    path: "/details/indexOG",
    component: _7ab81188,
    name: "details-indexOG"
  }, {
    path: "/district/create-district",
    component: _267582c1,
    name: "district-create-district"
  }, {
    path: "/product/Create-Product",
    component: _4c49865d,
    name: "product-Create-Product"
  }, {
    path: "/product/Create-Producty",
    component: _40e7736c,
    name: "product-Create-Producty"
  }, {
    path: "/reports/summery",
    component: _7f56b5ab,
    name: "reports-summery"
  }, {
    path: "/banks/:banksid",
    component: _109646cc,
    name: "banks-banksid"
  }, {
    path: "/details/:detailsid",
    component: _4b642d20,
    name: "details-detailsid"
  }, {
    path: "/district/:districtid",
    component: _0849d4ca,
    name: "district-districtid"
  }, {
    path: "/product/:productid",
    component: _96cda1ec,
    name: "product-productid"
  }, {
    path: "/",
    component: _42544f22,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
